﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button14 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Type 1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox7);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Location = new System.Drawing.Point(393, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(395, 144);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "State Space";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(136, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(221, 20);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.Text = "Position(x, y, z)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "Total Type Count";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.comboBox6);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.button12);
            this.groupBox2.Controls.Add(this.button11);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(393, 194);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(395, 153);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Action Space";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(18, 60);
            this.label22.Name = "label22";
            this.label22.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label22.Size = new System.Drawing.Size(112, 12);
            this.label22.TabIndex = 0;
            this.label22.Text = "Total Action Types";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(26, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(169, 57);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(658, 27);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(33, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "...";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(83, 29);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(569, 21);
            this.textBox12.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(17, 32);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 12);
            this.label21.TabIndex = 5;
            this.label21.Text = "Ant xml";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(17, 59);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(39, 12);
            this.label25.TabIndex = 5;
            this.label25.Text = "Legs#";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox12);
            this.groupBox3.Controls.Add(this.comboBox4);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Location = new System.Drawing.Point(393, 374);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(712, 98);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Other Parameters";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(83, 56);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(608, 20);
            this.comboBox4.TabIndex = 3;
            // 
            // label26
            // 
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label26.Location = new System.Drawing.Point(205, 175);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(900, 2);
            this.label26.TabIndex = 7;
            this.label26.Text = "label26";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox20);
            this.groupBox4.Controls.Add(this.comboBox5);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.button6);
            this.groupBox4.Controls.Add(this.textBox19);
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.textBox18);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.textBox15);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Location = new System.Drawing.Point(393, 491);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(712, 179);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Proporty of Objects";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(160, 139);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(492, 21);
            this.textBox20.TabIndex = 4;
            this.textBox20.Text = "A:\\InteractionBehavior\\adversarial-strict.cs";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(258, 28);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(433, 20);
            this.comboBox5.TabIndex = 3;
            this.comboBox5.Text = "Num 1";
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(18, 31);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(234, 12);
            this.label31.TabIndex = 5;
            this.label31.Text = "Replacement Shortcut :                Ctrl + ";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(658, 137);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(33, 23);
            this.button6.TabIndex = 3;
            this.button6.Text = "...";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(160, 112);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(492, 21);
            this.textBox19.TabIndex = 4;
            this.textBox19.Text = "A:\\InteractionBehavior\\adversarial-soft.cs";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(658, 110);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(33, 23);
            this.button5.TabIndex = 3;
            this.button5.Text = "...";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(160, 85);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(492, 21);
            this.textBox18.TabIndex = 4;
            this.textBox18.Text = "A:\\InteractionBehavior\\friendly-strict.cs";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(17, 142);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(102, 12);
            this.label30.TabIndex = 5;
            this.label30.Text = "Object Property 4";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(658, 83);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(33, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "...";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(17, 115);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(102, 12);
            this.label29.TabIndex = 5;
            this.label29.Text = "Object Property 3";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(160, 58);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(492, 21);
            this.textBox15.TabIndex = 4;
            this.textBox15.Text = "A:\\InteractionBehavior\\friendly-soft.cs";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(17, 88);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(102, 12);
            this.label27.TabIndex = 5;
            this.label27.Text = "Object Property 2";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(658, 56);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(33, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(17, 61);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(102, 12);
            this.label28.TabIndex = 5;
            this.label28.Text = "Object Property 1";
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("한컴 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button8.Location = new System.Drawing.Point(262, 978);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(212, 42);
            this.button8.TabIndex = 10;
            this.button8.Text = "Reset";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("한컴 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button9.Location = new System.Drawing.Point(500, 978);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(212, 42);
            this.button9.TabIndex = 10;
            this.button9.Text = "Apply Changes";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("한컴 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button10.Location = new System.Drawing.Point(747, 978);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(212, 42);
            this.button10.TabIndex = 10;
            this.button10.Text = "Quit";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(136, 55);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(125, 21);
            this.textBox4.TabIndex = 1;
            this.textBox4.Text = "2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "Type 2";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(136, 107);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(221, 20);
            this.comboBox2.TabIndex = 3;
            this.comboBox2.Text = "Augular Velocity(Vx, Vy, Vz)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(272, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "Dimension : 6";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Joint#";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(74, 29);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(283, 20);
            this.comboBox6.TabIndex = 3;
            this.comboBox6.Text = "Leg10";
            this.comboBox6.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "Unique ID";
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(83, 29);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(272, 20);
            this.comboBox7.TabIndex = 3;
            this.comboBox7.Text = "Leg10";
            this.comboBox7.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(136, 57);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(221, 21);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "Action Type 1";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(324, 82);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(33, 23);
            this.button11.TabIndex = 3;
            this.button11.Text = "...";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(529, 278);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(177, 21);
            this.textBox2.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "Action Type 2";
            this.label7.Click += new System.EventHandler(this.label6_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(324, 111);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(33, 23);
            this.button12.TabIndex = 3;
            this.button12.Text = "...";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(136, 111);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(177, 21);
            this.textBox3.TabIndex = 4;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox5);
            this.groupBox6.Controls.Add(this.comboBox3);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.button13);
            this.groupBox6.Controls.Add(this.textBox6);
            this.groupBox6.Controls.Add(this.button14);
            this.groupBox6.Controls.Add(this.textBox7);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.button15);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.textBox8);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.button16);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Location = new System.Drawing.Point(1159, 491);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(712, 179);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Reward of Actions";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(160, 139);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(492, 21);
            this.textBox5.TabIndex = 4;
            this.textBox5.Text = "A:\\RewardsOfActions\\Reward4.cs";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(258, 28);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(433, 20);
            this.comboBox3.TabIndex = 3;
            this.comboBox3.Text = "Num 1";
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(234, 12);
            this.label9.TabIndex = 5;
            this.label9.Text = "Replacement Shortcut :                Ctrl + ";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(658, 137);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(33, 23);
            this.button13.TabIndex = 3;
            this.button13.Text = "...";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(160, 112);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(492, 21);
            this.textBox6.TabIndex = 4;
            this.textBox6.Text = "A:\\RewardsOfActions\\Reward3.cs";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(658, 110);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(33, 23);
            this.button14.TabIndex = 3;
            this.button14.Text = "...";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(160, 85);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(492, 21);
            this.textBox7.TabIndex = 4;
            this.textBox7.Text = "A:\\RewardsOfActions\\Reward2.cs";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 142);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 12);
            this.label10.TabIndex = 5;
            this.label10.Text = "Reward 4";
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(658, 83);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(33, 23);
            this.button15.TabIndex = 3;
            this.button15.Text = "...";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 115);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 12);
            this.label11.TabIndex = 5;
            this.label11.Text = "Reward 3";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(160, 58);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(492, 21);
            this.textBox8.TabIndex = 4;
            this.textBox8.Text = "A:\\RewardsOfActions\\Reward1.cs";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 88);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 12);
            this.label12.TabIndex = 5;
            this.label12.Text = "Reward 2";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(658, 56);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(33, 23);
            this.button16.TabIndex = 3;
            this.button16.Text = "...";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(17, 61);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 12);
            this.label13.TabIndex = 5;
            this.label13.Text = "Reward 1";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.groupBox5);
            this.groupBox7.Controls.Add(this.checkBox4);
            this.groupBox7.Controls.Add(this.checkBox3);
            this.groupBox7.Controls.Add(this.checkBox2);
            this.groupBox7.Controls.Add(this.checkBox1);
            this.groupBox7.Controls.Add(this.label67);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.label35);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.textBox44);
            this.groupBox7.Controls.Add(this.textBox43);
            this.groupBox7.Controls.Add(this.textBox21);
            this.groupBox7.Controls.Add(this.label65);
            this.groupBox7.Controls.Add(this.textBox22);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Location = new System.Drawing.Point(1147, 686);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(759, 319);
            this.groupBox7.TabIndex = 12;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Environment Change";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label63);
            this.groupBox5.Controls.Add(this.label55);
            this.groupBox5.Controls.Add(this.label47);
            this.groupBox5.Controls.Add(this.label62);
            this.groupBox5.Controls.Add(this.label54);
            this.groupBox5.Controls.Add(this.label42);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.textBox42);
            this.groupBox5.Controls.Add(this.label61);
            this.groupBox5.Controls.Add(this.label53);
            this.groupBox5.Controls.Add(this.button7);
            this.groupBox5.Controls.Add(this.label64);
            this.groupBox5.Controls.Add(this.label46);
            this.groupBox5.Controls.Add(this.label60);
            this.groupBox5.Controls.Add(this.label52);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.textBox23);
            this.groupBox5.Controls.Add(this.textBox41);
            this.groupBox5.Controls.Add(this.textBox35);
            this.groupBox5.Controls.Add(this.textBox31);
            this.groupBox5.Controls.Add(this.textBox40);
            this.groupBox5.Controls.Add(this.textBox39);
            this.groupBox5.Controls.Add(this.textBox34);
            this.groupBox5.Controls.Add(this.textBox33);
            this.groupBox5.Controls.Add(this.label59);
            this.groupBox5.Controls.Add(this.textBox30);
            this.groupBox5.Controls.Add(this.label51);
            this.groupBox5.Controls.Add(this.textBox38);
            this.groupBox5.Controls.Add(this.textBox29);
            this.groupBox5.Controls.Add(this.textBox32);
            this.groupBox5.Controls.Add(this.textBox37);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.textBox26);
            this.groupBox5.Controls.Add(this.label58);
            this.groupBox5.Controls.Add(this.textBox27);
            this.groupBox5.Controls.Add(this.label50);
            this.groupBox5.Controls.Add(this.label57);
            this.groupBox5.Controls.Add(this.textBox24);
            this.groupBox5.Controls.Add(this.label49);
            this.groupBox5.Controls.Add(this.textBox36);
            this.groupBox5.Controls.Add(this.label40);
            this.groupBox5.Controls.Add(this.textBox25);
            this.groupBox5.Controls.Add(this.label56);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.label48);
            this.groupBox5.Controls.Add(this.textBox28);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Location = new System.Drawing.Point(28, 120);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(712, 175);
            this.groupBox5.TabIndex = 25;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Entities(Obstacles)";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(430, 138);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(13, 12);
            this.label63.TabIndex = 2;
            this.label63.Text = "X";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(430, 110);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(13, 12);
            this.label55.TabIndex = 2;
            this.label55.Text = "X";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(430, 83);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(13, 12);
            this.label47.TabIndex = 2;
            this.label47.Text = "X";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(134, 138);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(13, 12);
            this.label62.TabIndex = 2;
            this.label62.Text = "X";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(134, 110);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(13, 12);
            this.label54.TabIndex = 2;
            this.label54.Text = "X";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(134, 83);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(13, 12);
            this.label42.TabIndex = 2;
            this.label42.Text = "X";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(17, 137);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(58, 12);
            this.label39.TabIndex = 5;
            this.label39.Text = "Entity 3 : ";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(17, 110);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(58, 12);
            this.label38.TabIndex = 5;
            this.label38.Text = "Entity 2 : ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(18, 83);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(58, 12);
            this.label37.TabIndex = 5;
            this.label37.Text = "Entity 1 : ";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(13, 27);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(113, 12);
            this.label36.TabIndex = 5;
            this.label36.Text = "Total Entity Count :";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(153, 51);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(479, 21);
            this.textBox42.TabIndex = 4;
            this.textBox42.Text = "A:\\Model\\Obstacle1.fbx";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(596, 138);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(13, 12);
            this.label61.TabIndex = 2;
            this.label61.Text = "Z";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(596, 110);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(13, 12);
            this.label53.TabIndex = 2;
            this.label53.Text = "Z";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(638, 49);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(33, 23);
            this.button7.TabIndex = 3;
            this.button7.Text = "...";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(17, 54);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(105, 12);
            this.label64.TabIndex = 5;
            this.label64.Text = "Entity 3D Model : ";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(596, 83);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(13, 12);
            this.label46.TabIndex = 2;
            this.label46.Text = "Z";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(300, 138);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(13, 12);
            this.label60.TabIndex = 2;
            this.label60.Text = "Z";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(300, 110);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(13, 12);
            this.label52.TabIndex = 2;
            this.label52.Text = "Z";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(300, 83);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(13, 12);
            this.label41.TabIndex = 2;
            this.label41.Text = "Z";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(153, 24);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(518, 21);
            this.textBox23.TabIndex = 1;
            this.textBox23.Text = "3";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(615, 135);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(56, 21);
            this.textBox41.TabIndex = 1;
            this.textBox41.Text = "0";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(615, 107);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(56, 21);
            this.textBox35.TabIndex = 1;
            this.textBox35.Text = "0";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(615, 80);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(56, 21);
            this.textBox31.TabIndex = 1;
            this.textBox31.Text = "0";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(449, 135);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(56, 21);
            this.textBox40.TabIndex = 1;
            this.textBox40.Text = "0";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(319, 135);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(56, 21);
            this.textBox39.TabIndex = 1;
            this.textBox39.Text = "10";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(449, 107);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(56, 21);
            this.textBox34.TabIndex = 1;
            this.textBox34.Text = "0";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(319, 107);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(56, 21);
            this.textBox33.TabIndex = 1;
            this.textBox33.Text = "10";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(511, 138);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(13, 12);
            this.label59.TabIndex = 2;
            this.label59.Text = "Y";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(449, 80);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(56, 21);
            this.textBox30.TabIndex = 1;
            this.textBox30.Text = "0";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(511, 110);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(13, 12);
            this.label51.TabIndex = 2;
            this.label51.Text = "Y";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(153, 135);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(56, 21);
            this.textBox38.TabIndex = 1;
            this.textBox38.Text = "0";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(319, 80);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(56, 21);
            this.textBox29.TabIndex = 1;
            this.textBox29.Text = "0";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(153, 107);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(56, 21);
            this.textBox32.TabIndex = 1;
            this.textBox32.Text = "10";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(530, 135);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(56, 21);
            this.textBox37.TabIndex = 1;
            this.textBox37.Text = "0";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(511, 83);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(13, 12);
            this.label45.TabIndex = 2;
            this.label45.Text = "Y";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(530, 107);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(56, 21);
            this.textBox26.TabIndex = 1;
            this.textBox26.Text = "0";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(215, 138);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(13, 12);
            this.label58.TabIndex = 2;
            this.label58.Text = "Y";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(153, 80);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(56, 21);
            this.textBox27.TabIndex = 1;
            this.textBox27.Text = "0";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(215, 110);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(13, 12);
            this.label50.TabIndex = 2;
            this.label50.Text = "Y";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(401, 138);
            this.label57.Name = "label57";
            this.label57.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label57.Size = new System.Drawing.Size(23, 12);
            this.label57.TabIndex = 0;
            this.label57.Text = "Vel";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(530, 80);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(56, 21);
            this.textBox24.TabIndex = 1;
            this.textBox24.Text = "0";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(401, 110);
            this.label49.Name = "label49";
            this.label49.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label49.Size = new System.Drawing.Size(23, 12);
            this.label49.TabIndex = 0;
            this.label49.Text = "Vel";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(234, 135);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(56, 21);
            this.textBox36.TabIndex = 1;
            this.textBox36.Text = "0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(215, 83);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(13, 12);
            this.label40.TabIndex = 2;
            this.label40.Text = "Y";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(234, 107);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(56, 21);
            this.textBox25.TabIndex = 1;
            this.textBox25.Text = "10";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(105, 138);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(27, 12);
            this.label56.TabIndex = 0;
            this.label56.Text = "Pos";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(401, 83);
            this.label44.Name = "label44";
            this.label44.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label44.Size = new System.Drawing.Size(23, 12);
            this.label44.TabIndex = 0;
            this.label44.Text = "Vel";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(105, 110);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(27, 12);
            this.label48.TabIndex = 0;
            this.label48.Text = "Pos";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(234, 80);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(56, 21);
            this.textBox28.TabIndex = 1;
            this.textBox28.Text = "0";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(105, 83);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(27, 12);
            this.label43.TabIndex = 0;
            this.label43.Text = "Pos";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox4.Location = new System.Drawing.Point(541, 32);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(58, 16);
            this.checkBox4.TabIndex = 21;
            this.checkBox4.Text = "Tiled?";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(448, 85);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(57, 16);
            this.checkBox3.TabIndex = 22;
            this.checkBox3.Text = "MJFC";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(286, 85);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(73, 16);
            this.checkBox2.TabIndex = 23;
            this.checkBox2.Text = "pyBullet ";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(148, 85);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(78, 16);
            this.checkBox1.TabIndex = 24;
            this.checkBox1.Text = "PhysicsX";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(146, 59);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(13, 12);
            this.label67.TabIndex = 17;
            this.label67.Text = "X";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(146, 32);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(35, 12);
            this.label34.TabIndex = 18;
            this.label34.Text = "Width";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(26, 86);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(106, 12);
            this.label35.TabIndex = 10;
            this.label35.Text = "Physics Engine : ";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(26, 59);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(67, 12);
            this.label66.TabIndex = 11;
            this.label66.Text = "Tile Size : ";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(26, 32);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(83, 12);
            this.label32.TabIndex = 12;
            this.label32.Text = "Ground Size :";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(187, 56);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(125, 21);
            this.textBox44.TabIndex = 13;
            this.textBox44.Text = "100";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(382, 56);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(123, 21);
            this.textBox43.TabIndex = 14;
            this.textBox43.Text = "100";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(187, 29);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(125, 21);
            this.textBox21.TabIndex = 15;
            this.textBox21.Text = "100";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(333, 59);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(13, 12);
            this.label65.TabIndex = 19;
            this.label65.Text = "Y";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(382, 29);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(123, 21);
            this.textBox22.TabIndex = 16;
            this.textBox22.Text = "100";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(333, 32);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(43, 12);
            this.label33.TabIndex = 20;
            this.label33.Text = "Length";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBox9);
            this.groupBox8.Controls.Add(this.comboBox8);
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.button17);
            this.groupBox8.Controls.Add(this.textBox10);
            this.groupBox8.Controls.Add(this.button18);
            this.groupBox8.Controls.Add(this.textBox11);
            this.groupBox8.Controls.Add(this.label15);
            this.groupBox8.Controls.Add(this.button19);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.textBox13);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.button20);
            this.groupBox8.Controls.Add(this.label18);
            this.groupBox8.Location = new System.Drawing.Point(393, 728);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(712, 179);
            this.groupBox8.TabIndex = 6;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Goal Change";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(160, 139);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(492, 21);
            this.textBox9.TabIndex = 4;
            this.textBox9.Text = "A:\\Goals\\goal4.cs";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(258, 28);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(433, 20);
            this.comboBox8.TabIndex = 3;
            this.comboBox8.Text = "Num 2";
            this.comboBox8.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(18, 31);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(234, 12);
            this.label14.TabIndex = 5;
            this.label14.Text = "Replacement Shortcut :                Ctrl + ";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(658, 137);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(33, 23);
            this.button17.TabIndex = 3;
            this.button17.Text = "...";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(160, 112);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(492, 21);
            this.textBox10.TabIndex = 4;
            this.textBox10.Text = "A:\\Goals\\goal3.cs";
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(658, 110);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(33, 23);
            this.button18.TabIndex = 3;
            this.button18.Text = "...";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(160, 85);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(492, 21);
            this.textBox11.TabIndex = 4;
            this.textBox11.Text = "A:\\Goals\\goal2.cs";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(17, 142);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 12);
            this.label15.TabIndex = 5;
            this.label15.Text = "Goal Template 4";
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(658, 83);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(33, 23);
            this.button19.TabIndex = 3;
            this.button19.Text = "...";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(17, 115);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(98, 12);
            this.label16.TabIndex = 5;
            this.label16.Text = "Goal Template 3";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(160, 58);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(492, 21);
            this.textBox13.TabIndex = 4;
            this.textBox13.Text = "A:\\Goals\\goal1.cs";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(17, 88);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 12);
            this.label17.TabIndex = 5;
            this.label17.Text = "Goal Template 2";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(658, 56);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(33, 23);
            this.button20.TabIndex = 3;
            this.button20.Text = "...";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(17, 61);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 12);
            this.label18.TabIndex = 5;
            this.label18.Text = "Goal Template 1";
            // 
            // groupBox9
            // 
            this.groupBox9.Location = new System.Drawing.Point(1248, 58);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(712, 289);
            this.groupBox9.TabIndex = 6;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Domain Editor";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(2062, 1060);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Novelty Authoring Tool for CSONG : Control Suite with Open-World Novelty Generato" +
    "r";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox9;
    }
}

