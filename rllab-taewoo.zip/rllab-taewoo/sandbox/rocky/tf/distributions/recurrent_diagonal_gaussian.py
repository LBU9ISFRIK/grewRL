


from sandbox.rocky.tf.distributions.diagonal_gaussian import DiagonalGaussian

RecurrentDiagonalGaussian = DiagonalGaussian
